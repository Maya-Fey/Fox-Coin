FoxCoin (FOX)

https://bitcointalk.org/index.php?topic=420727.0